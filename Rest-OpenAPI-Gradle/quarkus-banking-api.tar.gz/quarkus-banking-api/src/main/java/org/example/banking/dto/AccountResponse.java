package org.example.banking.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Response containing account details")
public class AccountResponse {
    public String customerId;
    public String accountNumber;
    public String accountType;
    public double balance;

    public AccountResponse(String customerId, String accountNumber, String accountType, double balance) {
        this.customerId = customerId;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }
}