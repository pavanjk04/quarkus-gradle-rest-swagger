package org.example.banking.resource;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.example.banking.Account;
import org.example.banking.dto.AccountRequest;
import org.example.banking.dto.AccountResponse;
import org.example.banking.service.AccountService;

import java.util.List;
import java.util.stream.Collectors;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.APIResponse;

@Path("/accounts")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AccountResource {

    @Inject
    AccountService service;

    @POST
    @Path("/{customerId}")
    @Operation(summary = "Create an account for a customer")
    @APIResponse(responseCode = "201", description = "Account created successfully")
    public Response createAccount(@PathParam("customerId") String customerId, AccountRequest request) {
        Account account = new Account(customerId, request.accountNumber, request.accountType, request.balance);
        Account created = service.createAccount(account);
        return Response.status(Response.Status.CREATED)
                       .entity(new AccountResponse(created.getCustomerId(), created.getAccountNumber(), created.getAccountType(), created.getBalance()))
                       .build();
    }

    @GET
    @Path("/{customerId}")
    @Operation(summary = "Get all accounts for a customer")
    @APIResponse(responseCode = "200", description = "List of accounts")
    @APIResponse(responseCode = "404", description = "Customer not found")
    public Response getAccounts(@PathParam("customerId") String customerId) {
        List<Account> accounts = service.getAccounts(customerId);
        if (accounts.isEmpty()) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        List<AccountResponse> response = accounts.stream()
            .map(a -> new AccountResponse(a.getCustomerId(), a.getAccountNumber(), a.getAccountType(), a.getBalance()))
            .collect(Collectors.toList());
        return Response.ok(response).build();
    }
}