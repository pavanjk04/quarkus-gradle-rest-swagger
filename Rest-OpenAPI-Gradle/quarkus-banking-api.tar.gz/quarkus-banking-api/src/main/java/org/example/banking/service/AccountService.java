package org.example.banking.service;

import jakarta.enterprise.context.ApplicationScoped;
import org.example.banking.Account;

import java.util.*;

@ApplicationScoped
public class AccountService {
    private final Map<String, List<Account>> store = new HashMap<>();

    public List<Account> getAccounts(String customerId) {
        return store.getOrDefault(customerId, new ArrayList<>());
    }

    public Account createAccount(Account account) {
        store.computeIfAbsent(account.getCustomerId(), k -> new ArrayList<>()).add(account);
        return account;
    }
}