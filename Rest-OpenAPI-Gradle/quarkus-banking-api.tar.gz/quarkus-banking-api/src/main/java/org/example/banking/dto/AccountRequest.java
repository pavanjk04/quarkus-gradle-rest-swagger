package org.example.banking.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Request to create a new account")
public class AccountRequest {
    @Schema(example = "ACC123")
    public String accountNumber;

    @Schema(example = "SAVINGS")
    public String accountType;

    @Schema(example = "1000.00")
    public double balance;
}